// src/components/common/ProjectSelector.jsx
import React from 'react';
import { Dropdown } from 'react-bootstrap';
import { useProject } from '../../contexts/ProjectContext';

const ProjectSelector = ({ onCreateProject }) => {
  const { projects, currentProject, switchProject } = useProject();
  
  const handleSelectProject = (projectId) => {
    switchProject(projectId);
  };
  
  return (
    <Dropdown>
      <Dropdown.Toggle 
        as="div" 
        className="d-flex align-items-center cursor-pointer"
      >
        <div 
          className="d-flex align-items-center justify-content-center rounded-circle text-white me-2"
          style={{ width: '32px', height: '32px', backgroundColor: '#007bff', fontSize: '14px' }}
        >
          <span>F</span>
        </div>
        <span className="fw-bold me-1">{currentProject?.name || 'Select Project'}</span>
        <i className="bi bi-chevron-down text-muted"></i>
      </Dropdown.Toggle>
      
      <Dropdown.Menu className="shadow border-0">
        {projects.length > 0 && (
          <>
            {projects.map(project => (
              <Dropdown.Item 
                key={project.id}
                active={currentProject && currentProject.id === project.id}
                onClick={() => handleSelectProject(project.id)}
              >
                <div className="d-flex align-items-center">
                  <div 
                    className="d-flex align-items-center justify-content-center rounded-circle text-white me-2"
                    style={{ width: '28px', height: '28px', backgroundColor: '#007bff', fontSize: '12px' }}
                  >
                    <span>{project.name.charAt(0)}</span>
                  </div>
                  <span>{project.name}</span>
                </div>
              </Dropdown.Item>
            ))}
            <Dropdown.Divider />
          </>
        )}
        
        <Dropdown.Item onClick={onCreateProject}>
          <div className="d-flex align-items-center text-primary">
            <i className="bi bi-plus-circle me-2"></i>
            <span>Create New Project</span>
          </div>
        </Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default ProjectSelector;
