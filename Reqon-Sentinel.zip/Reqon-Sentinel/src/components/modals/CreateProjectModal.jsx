// src/components/modals/CreateProjectModal.jsx
import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Spinner } from 'react-bootstrap';
import { useProject } from '../../contexts/ProjectContext';

const CreateProjectModal = ({ show, onHide }) => {
  const { createProject } = useProject();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [projectName, setProjectName] = useState('');
  const [errors, setErrors] = useState({});
  
  // Reset form when modal is opened
  useEffect(() => {
    if (show) {
      setWebsiteUrl('');
      setProjectName('');
      setErrors({});
    }
  }, [show]);
  
  // Auto-suggest project name based on URL
  useEffect(() => {
    if (websiteUrl) {
      try {
        const url = new URL(websiteUrl.startsWith('http') ? websiteUrl : `https://${websiteUrl}`);
        const domain = url.hostname.replace('www.', '');
        const suggestedName = domain.split('.')[0]; // Get the first part of the domain
        
        // Only auto-fill if the user hasn't manually entered a name
        if (!projectName) {
          setProjectName(suggestedName.charAt(0).toUpperCase() + suggestedName.slice(1));
        }
      } catch (error) {
        // Invalid URL, don't auto-suggest
      }
    }
  }, [websiteUrl, projectName]);
  
  // Validate the form
  const validateForm = () => {
    const newErrors = {};
    
    if (!projectName.trim()) {
      newErrors.projectName = 'Project name is required';
    }
    
    if (!websiteUrl.trim()) {
      newErrors.websiteUrl = 'Website URL is required';
    } else {
      try {
        // Ensure URL is valid
        new URL(websiteUrl.startsWith('http') ? websiteUrl : `https://${websiteUrl}`);
      } catch (error) {
        newErrors.websiteUrl = 'Please enter a valid URL';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Ensure URL has a protocol
      const formattedUrl = websiteUrl.startsWith('http') 
        ? websiteUrl 
        : `https://${websiteUrl}`;
      
      await createProject(projectName, formattedUrl);
      onHide();
    } catch (error) {
      console.error('Failed to create project:', error);
      setErrors({ form: 'Failed to create project. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Modal
      show={show}
      onHide={onHide}
      centered
      backdrop="static"
      keyboard={!isSubmitting}
    >
      <Modal.Header closeButton={!isSubmitting}>
        <Modal.Title>Create New Project</Modal.Title>
      </Modal.Header>
      
      <Modal.Body>
        <p className="text-muted mb-4">
          Create a new project to start testing your website with ReQon AI-powered quality assurance.
        </p>
        
        {errors.form && (
          <div className="alert alert-danger">{errors.form}</div>
        )}
        
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Website URL</Form.Label>
            <Form.Control
              type="text"
              placeholder="e.g., https://example.com"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              isInvalid={!!errors.websiteUrl}
              disabled={isSubmitting}
              autoFocus
            />
            <Form.Control.Feedback type="invalid">
              {errors.websiteUrl}
            </Form.Control.Feedback>
            <Form.Text className="text-muted">
              Enter the URL of the website you want to test
            </Form.Text>
          </Form.Group>
          
          <Form.Group className="mb-3">
            <Form.Label>Project Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="e.g., My E-commerce Website"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              isInvalid={!!errors.projectName}
              disabled={isSubmitting}
            />
            <Form.Control.Feedback type="invalid">
              {errors.projectName}
            </Form.Control.Feedback>
            <Form.Text className="text-muted">
              A name will be suggested based on the URL
            </Form.Text>
          </Form.Group>
        </Form>
      </Modal.Body>
      
      <Modal.Footer>
        <Button 
          variant="light" 
          onClick={onHide} 
          disabled={isSubmitting}
        >
          Cancel
        </Button>
        <Button 
          variant="primary" 
          onClick={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <Spinner
                as="span"
                animation="border"
                size="sm"
                role="status"
                aria-hidden="true"
                className="me-2"
              />
              Creating...
            </>
          ) : (
            'Create Project'
          )}
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default CreateProjectModal;