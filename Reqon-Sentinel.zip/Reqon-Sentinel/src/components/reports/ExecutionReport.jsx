// src/components/reports/ExecutionReport.jsx
import React, { useState } from 'react';
import { Modal, Button, Tab, Nav, Card, Badge, Row, Col, ListGroup } from 'react-bootstrap';

const ExecutionReport = ({ execution, show, onHide }) => {
  const [activeTab, setActiveTab] = useState('summary');
  
  if (!execution) return null;
  
  // Get status badge
  const getStatusBadge = (status) => {
    switch(status.toLowerCase()) {
      case 'passed':
        return <Badge bg="success">Passed</Badge>;
      case 'failed':
        return <Badge bg="danger">Failed</Badge>;
      case 'running':
        return <Badge bg="warning">Running</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };
  
  // Mock data for the report
  const mockFailures = [
    {
      message: "Expected element to be visible, but it was not found",
      location: "At step: User fills out contact form",
      elementId: "#contact-form"
    },
    {
      message: "Timeout waiting for element to appear",
      location: "At step: User submits the form",
      elementId: ".submit-button"
    }
  ];
  
  return (
    <Modal 
      show={show} 
      onHide={onHide}
      centered
      size="lg"
    >
      <Modal.Header closeButton>
        <Modal.Title className="d-flex align-items-center">
          <i className="bi bi-file-earmark-text me-2 text-primary"></i>
          {execution.name}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="mb-4">
          <Row className="g-3">
            <Col md={6}>
              <div className="d-flex flex-column">
                <div className="mb-2">
                  <span className="text-muted me-2">Execution Date:</span>
                  <span>{execution.date} at {execution.time}</span>
                </div>
                <div className="mb-2">
                  <span className="text-muted me-2">Execution Type:</span>
                  <Badge bg="light" text="dark">
                    <i className="bi bi-laptop me-1"></i>
                    {execution.type}
                  </Badge>
                </div>
                <div>
                  <span className="text-muted me-2">Status:</span>
                  {getStatusBadge(execution.status)}
                </div>
              </div>
            </Col>
            <Col md={6}>
              <div className="d-flex flex-column">
                <div className="mb-2">
                  <span className="text-muted me-2">Pass Ratio:</span>
                  <span>{execution.passRatio}</span>
                </div>
                <div className="mb-2">
                  <span className="text-muted me-2">User:</span>
                  <span>Dhamodhar</span>
                </div>
                <div>
                  <span className="text-muted me-2">Environment:</span>
                  <span>default</span>
                </div>
              </div>
            </Col>
          </Row>
        </div>
        
        <Tab.Container activeKey={activeTab} onSelect={setActiveTab}>
          <Nav variant="tabs" className="mb-3">
            <Nav.Item>
              <Nav.Link eventKey="summary">
                <i className="bi bi-clipboard-data me-2"></i>
                Summary
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="failures">
                <i className="bi bi-exclamation-circle me-2"></i>
                Failures
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="steps">
                <i className="bi bi-list-check me-2"></i>
                Steps
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="logs">
                <i className="bi bi-terminal me-2"></i>
                Logs
              </Nav.Link>
            </Nav.Item>
          </Nav>
          
          <Tab.Content>
            <Tab.Pane eventKey="summary">
              <Row className="g-3">
                <Col md={7}>
                  <Card className="h-100">
                    <Card.Header className="bg-white">
                      <h6 className="mb-0">Execution Overview</h6>
                    </Card.Header>
                    <Card.Body>
                      <div className="d-flex justify-content-center align-items-center" style={{ height: '200px' }}>
                        <div className="text-center">
                          <div className="d-flex justify-content-center mb-3">
                            <i className="bi bi-x-circle text-danger" style={{ fontSize: '5rem' }}></i>
                          </div>
                          <h5>Test Failed</h5>
                          <p className="text-muted mb-0">0/1 tests passed</p>
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col md={5}>
                  <Card className="h-100">
                    <Card.Header className="bg-white">
                      <h6 className="mb-0">Test Metrics</h6>
                    </Card.Header>
                    <ListGroup variant="flush">
                      <ListGroup.Item className="d-flex justify-content-between align-items-center">
                        <span className="text-muted">Total Duration</span>
                        <span className="fw-medium">5.2s</span>
                      </ListGroup.Item>
                      <ListGroup.Item className="d-flex justify-content-between align-items-center">
                        <span className="text-muted">Tests Run</span>
                        <span className="fw-medium">1</span>
                      </ListGroup.Item>
                      <ListGroup.Item className="d-flex justify-content-between align-items-center">
                        <span className="text-muted">Tests Passed</span>
                        <span className="fw-medium">0</span>
                      </ListGroup.Item>
                      <ListGroup.Item className="d-flex justify-content-between align-items-center">
                        <span className="text-muted">Tests Failed</span>
                        <span className="fw-medium">1</span>
                      </ListGroup.Item>
                    </ListGroup>
                  </Card>
                </Col>
              </Row>
            </Tab.Pane>
            
            <Tab.Pane eventKey="failures">
              <Card>
                <Card.Header className="bg-danger bg-opacity-10 text-danger">
                  <h6 className="mb-0">
                    <i className="bi bi-exclamation-triangle me-2"></i>
                    2 Failures Detected
                  </h6>
                </Card.Header>
                <ListGroup variant="flush">
                  {mockFailures.map((failure, index) => (
                    <ListGroup.Item key={index} className="border-start border-danger border-4">
                      <div className="d-flex flex-column">
                        <h6 className="text-danger mb-2">{failure.message}</h6>
                        <p className="text-muted mb-1">{failure.location}</p>
                        <div>
                          <Badge bg="light" text="dark">
                            <i className="bi bi-code me-1"></i>
                            {failure.elementId}
                          </Badge>
                        </div>
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="steps">
              <Card>
                <ListGroup variant="flush">
                  <ListGroup.Item className="d-flex align-items-center">
                    <Badge bg="success" pill className="me-3">1</Badge>
                    <div>
                      <p className="mb-0 fw-medium">Given The user navigates to the Contact page through the Home and Artificial Intelligence links</p>
                      <small className="text-success">Passed (0.8s)</small>
                    </div>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex align-items-center">
                    <Badge bg="success" pill className="me-3">2</Badge>
                    <div>
                      <p className="mb-0 fw-medium">When The user fills the contact form with full name, email address, company name</p>
                      <small className="text-success">Passed (1.2s)</small>
                    </div>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex align-items-center">
                    <Badge bg="danger" pill className="me-3">3</Badge>
                    <div>
                      <p className="mb-0 fw-medium">When The user navigates to the contact page by clicking on Get in Touch link</p>
                      <small className="text-danger">Failed (3.0s) - Element not found</small>
                    </div>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex align-items-center">
                    <Badge bg="secondary" pill className="me-3">4</Badge>
                    <div>
                      <p className="mb-0 fw-medium">When The user hovers on "Insights"</p>
                      <small className="text-muted">Skipped</small>
                    </div>
                  </ListGroup.Item>
                </ListGroup>
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="logs">
              <Card>
                <Card.Body>
                  <pre className="bg-dark text-light p-3 rounded" style={{ maxHeight: '300px', overflow: 'auto' }}>
{`[${execution.date} ${execution.time}] Starting test execution: ${execution.name}
[${execution.date} ${execution.time}] Running on environment: default
[${execution.date} ${execution.time}] Browser: Chrome 114.0.5735.198
[${execution.date} ${execution.time}] Step 1: Navigating to the Contact page
[${execution.date} ${execution.time}] ✓ Successfully navigated to Contact page
[${execution.date} ${execution.time}] Step 2: Filling out the contact form
[${execution.date} ${execution.time}] ✓ Form filled with test data
[${execution.date} ${execution.time}] Step 3: Clicking on "Get in Touch" link
[${execution.date} ${execution.time}] ✗ ERROR: Failed to find element: Get in Touch link
[${execution.date} ${execution.time}] Timeout waiting for element to appear
[${execution.date} ${execution.time}] Test execution failed
[${execution.date} ${execution.time}] Total execution time: 5.2s`}
                  </pre>
                </Card.Body>
              </Card>
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="outline-primary" className="me-auto">
          <i className="bi bi-download me-2"></i>
          Download Report
        </Button>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        <Button variant="primary">
          <i className="bi bi-play-fill me-2"></i>
          Re-run Test
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ExecutionReport;