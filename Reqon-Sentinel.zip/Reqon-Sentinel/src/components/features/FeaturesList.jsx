// src/components/features/FeaturesList.jsx
import React, { useState } from 'react';
import { Row, Col, Card, Badge, Button, Dropdown, Table } from 'react-bootstrap';
import FeatureDetail from './FeaturesDetail';

const FeaturesList = ({ features, viewMode }) => {
  const [selectedFeature, setSelectedFeature] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  
  // Get status badge variant
  const getStatusBadge = (status) => {
    const variant = status === 'Passed' ? 'success' : 'danger';
    const icon = status === 'Passed' ? 'bi-check-circle' : 'bi-x-circle';
    
    return (
      <Badge bg={variant} className="py-2 px-3 d-inline-flex align-items-center">
        <i className={`bi ${icon} me-1`}></i>
        {status}
      </Badge>
    );
  };
  
  // Handle view details
  const handleViewDetails = (feature) => {
    setSelectedFeature(feature);
    setShowDetailModal(true);
  };
  
  // Handle run test
  const handleRunTest = (feature) => {
    // Mock implementation - would trigger an actual test run
    console.log(`Running test for: ${feature.name}`);
  };
  
  // Grid View
  const GridView = () => (
    <Row className="g-3">
      {features.map((feature) => (
        <Col xs={12} sm={6} lg={4} key={feature.id}>
          <Card className="h-100 shadow-sm">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <h6 className="mb-1">{feature.name}</h6>
                  {feature.description && (
                    <p className="text-muted small mb-0">{feature.description}</p>
                  )}
                </div>
                <Dropdown align="end">
                  <Dropdown.Toggle variant="light" size="sm" id={`feature-${feature.id}-dropdown`}>
                    <i className="bi bi-three-dots-vertical"></i>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item onClick={() => handleViewDetails(feature)}>
                      <i className="bi bi-eye me-2"></i>
                      View Details
                    </Dropdown.Item>
                    <Dropdown.Item>
                      <i className="bi bi-pencil me-2"></i>
                      Edit
                    </Dropdown.Item>
                    <Dropdown.Divider />
                    <Dropdown.Item className="text-danger">
                      <i className="bi bi-trash me-2"></i>
                      Delete
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
              
              <div className="d-flex justify-content-between mb-3">
                <span className="text-muted">Status</span>
                {getStatusBadge(feature.status)}
              </div>
              
              <div className="d-flex justify-content-between mb-3">
                <span className="text-muted">Last Run</span>
                <span>{feature.lastRun}</span>
              </div>
              
              <div className="d-flex justify-content-between">
                <span className="text-muted">Scenarios</span>
                <Badge bg="secondary" pill className="px-3 py-2">
                  {feature.scenariosCount}
                </Badge>
              </div>
            </Card.Body>
            <Card.Footer className="bg-transparent">
              <div className="d-flex gap-2">
                <Button 
                  variant="outline-primary" 
                  className="w-100"
                  onClick={() => handleViewDetails(feature)}
                >
                  <i className="bi bi-eye me-2"></i>
                  View
                </Button>
                <Button 
                  variant="primary" 
                  className="w-100"
                  onClick={() => handleRunTest(feature)}
                >
                  <i className="bi bi-play-fill me-2"></i>
                  Run
                </Button>
              </div>
            </Card.Footer>
          </Card>
        </Col>
      ))}
    </Row>
  );
  
  // List View
  const ListView = () => (
    <Card className="shadow-sm">
      <div className="table-responsive">
        <Table className="align-middle mb-0">
          <thead className="table-light">
            <tr>
              <th>Name</th>
              <th>Scenarios</th>
              <th>Last Run</th>
              <th>Status</th>
              <th className="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            {features.map((feature) => (
              <tr key={feature.id}>
                <td>
                  <div>
                    <h6 className="mb-1">{feature.name}</h6>
                    {feature.description && (
                      <p className="text-muted small mb-0">{feature.description}</p>
                    )}
                  </div>
                </td>
                <td>
                  <Badge bg="secondary" pill className="px-3 py-2">
                    {feature.scenariosCount}
                  </Badge>
                </td>
                <td>{feature.lastRun}</td>
                <td>{getStatusBadge(feature.status)}</td>
                <td className="text-end">
                  <div className="d-flex justify-content-end gap-1">
                    <Button 
                      variant="outline-primary" 
                      size="sm"
                      onClick={() => handleViewDetails(feature)}
                    >
                      <i className="bi bi-eye"></i>
                    </Button>
                    <Button 
                      variant="primary" 
                      size="sm"
                      onClick={() => handleRunTest(feature)}
                    >
                      <i className="bi bi-play-fill"></i>
                    </Button>
                    <Dropdown align="end">
                      <Dropdown.Toggle variant="light" size="sm" id={`feature-list-${feature.id}-dropdown`}>
                        <i className="bi bi-three-dots-vertical"></i>
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item>
                          <i className="bi bi-pencil me-2"></i>
                          Edit
                        </Dropdown.Item>
                        <Dropdown.Divider />
                        <Dropdown.Item className="text-danger">
                          <i className="bi bi-trash me-2"></i>
                          Delete
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </Card>
  );
  
  return (
    <>
      {viewMode === 'grid' ? <GridView /> : <ListView />}
      
      {/* Feature Detail Modal */}
      <FeatureDetail 
        feature={selectedFeature}
        show={showDetailModal}
        onHide={() => setShowDetailModal(false)}
        onRun={handleRunTest}
      />
    </>
  );
};

export default FeaturesList;