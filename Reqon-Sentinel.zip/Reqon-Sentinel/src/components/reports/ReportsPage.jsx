// src/components/reports/ReportsPage.jsx
import React, { useState } from 'react';
import { Container, Row, Col, Card, Badge, Form, InputGroup, Button } from 'react-bootstrap';
import { mockExecutions } from '../../data/mockData';
import ExecutionReport from './ExecutionReport';
import EmptyState from '../common/EmptyState';

const ReportsPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [timeRange, setTimeRange] = useState('24h');
  const [selectedExecution, setSelectedExecution] = useState(null);
  const [showReportModal, setShowReportModal] = useState(false);
  
  // Filter executions based on search
  const filteredExecutions = mockExecutions.filter(execution =>
    execution.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    execution.type.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Get status badge
  const getStatusBadge = (status) => {
    switch(status.toLowerCase()) {
      case 'passed':
        return <Badge bg="success">Passed</Badge>;
      case 'failed':
        return <Badge bg="danger">Failed</Badge>;
      case 'running':
        return <Badge bg="warning">Running</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };
  
  // Show report detail
  const handleShowReport = (execution) => {
    setSelectedExecution(execution);
    setShowReportModal(true);
  };
  
  // Count statistics
  const totalExecutions = mockExecutions.length;
  const successfulExecutions = mockExecutions.filter(e => e.status.toLowerCase() === 'passed').length;
  const failedExecutions = mockExecutions.filter(e => e.status.toLowerCase() === 'failed').length;
  
  return (
    <Container fluid className="p-0">
      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-column flex-md-row">
        <div className="mb-3 mb-md-0">
          <h4 className="fw-bold mb-2">Reports</h4>
          <p className="text-muted">View detailed test execution reports</p>
        </div>
        <div className="d-flex align-items-center">
          <a href="#" className="text-decoration-none me-3">
            How to run scenarios <i className="bi bi-question-circle"></i>
          </a>
          <div className="dropdown">
            <Button 
              variant="outline-secondary"
              className="d-flex align-items-center"
              id="timeRangeDropdown"
            >
              <span>Show last 24 hours</span>
              <i className="bi bi-chevron-down ms-2"></i>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Statistics Row */}
      <Row className="g-3 mb-4">
        <Col md={4}>
          <Card className="shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="rounded-circle bg-light p-3 me-3">
                <i className="bi bi-play-circle text-primary fs-4"></i>
              </div>
              <div>
                <h6 className="text-muted mb-1">Total executions</h6>
                <h3 className="mb-0 fw-bold">{totalExecutions}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="rounded-circle bg-light p-3 me-3">
                <i className="bi bi-check-circle text-success fs-4"></i>
              </div>
              <div>
                <h6 className="text-muted mb-1">Successful</h6>
                <h3 className="mb-0 fw-bold">{successfulExecutions}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="rounded-circle bg-light p-3 me-3">
                <i className="bi bi-x-circle text-danger fs-4"></i>
              </div>
              <div>
                <h6 className="text-muted mb-1">Failed</h6>
                <h3 className="mb-0 fw-bold">{failedExecutions}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Executions */}
      <Card className="shadow-sm">
        <Card.Header className="bg-white">
          <h6 className="mb-0 fw-bold">Executions</h6>
        </Card.Header>
        <Card.Body className="p-3">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <InputGroup className="w-50">
              <InputGroup.Text>
                <i className="bi bi-search"></i>
              </InputGroup.Text>
              <Form.Control
                placeholder="Find a run..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </InputGroup>
          </div>
          
          {filteredExecutions.length > 0 ? (
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light">
                  <tr>
                    <th>Execution info</th>
                    <th>Execution date</th>
                    <th>Execution type</th>
                    <th>Status</th>
                    <th>Pass ratio</th>
                    <th>User</th>
                    <th>Environment</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredExecutions.map((execution, index) => (
                    <tr key={execution.id || index} onClick={() => handleShowReport(execution)} style={{ cursor: 'pointer' }}>
                      <td>
                        <div className="d-flex align-items-center">
                          <i className="bi bi-file-earmark-text text-primary me-2"></i>
                          <span>{execution.name}</span>
                        </div>
                      </td>
                      <td>
                        {execution.date} at {execution.time}
                      </td>
                      <td>
                        <Badge bg="light" text="dark">
                          <i className="bi bi-laptop me-1"></i>
                          {execution.type}
                        </Badge>
                      </td>
                      <td>
                        {getStatusBadge(execution.status)}
                      </td>
                      <td>{execution.passRatio}</td>
                      <td>Dhamodhar</td>
                      <td>default</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-4">
              <EmptyState 
                title="No executions found"
                description="Try changing your search or run a new test"
                icon="bi-search"
              />
            </div>
          )}
        </Card.Body>
      </Card>
      
      {/* Execution Report Modal */}
      <ExecutionReport 
        execution={selectedExecution}
        show={showReportModal}
        onHide={() => setShowReportModal(false)}
      />
    </Container>
  );
};

export default ReportsPage;