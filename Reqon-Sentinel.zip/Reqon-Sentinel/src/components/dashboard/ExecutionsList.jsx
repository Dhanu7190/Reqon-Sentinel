// src/components/dashboard/ExecutionsList.jsx
import React from 'react';
import { Table, Badge } from 'react-bootstrap';

const ExecutionsList = ({ executions }) => {
  // Get status badge variant
  const getStatusBadge = (status) => {
    switch(status.toLowerCase()) {
      case 'passed':
        return <Badge bg="success">Passed</Badge>;
      case 'failed':
        return <Badge bg="danger">Failed</Badge>;
      case 'running':
        return <Badge bg="warning">Running</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };
  
  // Get execution type badge
  const getExecutionTypeBadge = (type) => {
    return (
      <Badge bg="light" text="dark" className="d-flex align-items-center">
        <i className="bi bi-laptop me-1"></i>
        {type}
      </Badge>
    );
  };
  
  return (
    <div className="table-responsive">
      <Table className="mb-0">
        <thead className="table-light">
          <tr>
            <th>Execution name</th>
            <th>Execution date</th>
            <th>Execution type</th>
            <th>Status</th>
            <th>Pass ratio</th>
          </tr>
        </thead>
        <tbody>
          {executions.map((execution, index) => (
            <tr key={execution.id || index}>
              <td className="align-middle">
                <div className="d-flex align-items-center">
                  <span className="ms-2">{execution.name}</span>
                </div>
              </td>
              <td className="align-middle">
                {execution.date} at {execution.time}
              </td>
              <td className="align-middle">
                {getExecutionTypeBadge(execution.type)}
              </td>
              <td className="align-middle">
                {getStatusBadge(execution.status)}
              </td>
              <td className="align-middle">
                {execution.passRatio}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default ExecutionsList;