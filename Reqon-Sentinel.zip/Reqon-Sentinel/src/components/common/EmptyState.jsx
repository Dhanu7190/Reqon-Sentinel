// src/components/common/EmptyState.jsx
import React from 'react';
import { Card, Button } from 'react-bootstrap';

const EmptyState = ({ title, description, icon, actionText, onAction, className = '' }) => {
  return (
    <Card className={`border-0 shadow-sm ${className}`}>
      <Card.Body className="empty-state p-5">
        <div className="empty-state-icon">
          <i className={`bi ${icon}`}></i>
        </div>
        <h5 className="fw-bold mb-3">{title}</h5>
        <p className="text-muted mb-4">{description}</p>
        {actionText && onAction && (
          <Button 
            variant="primary" 
            onClick={onAction}
            className="rounded-pill px-4 py-2"
          >
            <i className={`bi ${icon} me-2`}></i>
            {actionText}
          </Button>
        )}
      </Card.Body>
    </Card>
  );
};

export default EmptyState;