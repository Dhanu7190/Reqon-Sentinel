// src/components/features/FeaturesPage.jsx
import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form, InputGroup, Badge, Dropdown, Nav, Tab } from 'react-bootstrap';
import { mockFeatures } from '../../data/mockData';
import FeaturesList from './FeaturesList';
import EmptyState from '../common/EmptyState';
import CreateFeatureModal from '../modals/CreateFeatureModal';

const FeaturesPage = () => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [viewMode, setViewMode] = useState('grid');
  
  // Filter features based on search and tab
  const filteredFeatures = mockFeatures.filter(feature => {
    // Search filter
    const searchFilter = 
      feature.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (feature.description && feature.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Tab filter
    const tabFilter = 
      activeTab === 'all' ? true : 
      activeTab === 'passed' ? feature.status === 'Passed' : 
      activeTab === 'failed' ? feature.status === 'Failed' : 
      true;
    
    return searchFilter && tabFilter;
  });
  
  // Count features by status
  const passedCount = mockFeatures.filter(f => f.status === 'Passed').length;
  const failedCount = mockFeatures.filter(f => f.status === 'Failed').length;
  
  // Handle record scenario
  const handleRecordScenario = () => {
    setShowCreateModal(true);
  };
  
  return (
    <Container fluid className="p-0">
      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-column flex-md-row">
        <div className="mb-3 mb-md-0">
          <h4 className="fw-bold mb-2">Feature Sets</h4>
          <p className="text-muted">Manage test scenarios for your website</p>
        </div>
        <div className="d-flex gap-2">
          <Button 
            variant="outline-primary"
            className="d-flex align-items-center"
            onClick={() => {}}
          >
            <i className="bi bi-download me-2"></i>
            Download Scout
          </Button>
          <Button 
            variant="primary"
            className="d-flex align-items-center"
            onClick={handleRecordScenario}
          >
            <i className="bi bi-plus-circle me-2"></i>
            Create Feature Set
          </Button>
        </div>
      </div>
      
      {/* Filter Bar */}
      <Card className="mb-3 shadow-sm">
        <Card.Body>
          <Row className="g-3 align-items-center">
            <Col xs={12} md={5}>
              <InputGroup>
                <InputGroup.Text className="bg-transparent">
                  <i className="bi bi-search text-muted"></i>
                </InputGroup.Text>
                <Form.Control
                  placeholder="Search feature sets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </InputGroup>
            </Col>
            <Col xs={12} md={3}>
              <Form.Select defaultValue="lastRun">
                <option value="lastRun">Sort by: Last Run</option>
                <option value="name">Sort by: Name</option>
                <option value="status">Sort by: Status</option>
              </Form.Select>
            </Col>
            <Col xs={12} md={4} className="d-flex justify-content-md-end">
              <div className="btn-group">
                <Button
                  variant={viewMode === 'list' ? 'primary' : 'outline-primary'}
                  onClick={() => setViewMode('list')}
                >
                  <i className="bi bi-list"></i>
                </Button>
                <Button
                  variant={viewMode === 'grid' ? 'primary' : 'outline-primary'}
                  onClick={() => setViewMode('grid')}
                >
                  <i className="bi bi-grid"></i>
                </Button>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>
      
      {/* Tabs */}
      <Nav 
        variant="tabs" 
        className="mb-4" 
        activeKey={activeTab}
        onSelect={setActiveTab}
      >
        <Nav.Item>
          <Nav.Link eventKey="all">
            All
            <Badge bg="secondary" pill className="ms-2">
              {mockFeatures.length}
            </Badge>
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="passed">
            Passed
            <Badge bg="success" pill className="ms-2">
              {passedCount}
            </Badge>
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link eventKey="failed">
            Failed
            <Badge bg="danger" pill className="ms-2">
              {failedCount}
            </Badge>
          </Nav.Link>
        </Nav.Item>
      </Nav>
      
      {mockFeatures.length > 0 ? (
        <FeaturesList 
          features={filteredFeatures} 
          viewMode={viewMode} 
        />
      ) : (
        <EmptyState 
          title="No Feature Sets Yet"
          description="Start by creating your first feature set or recording a scenario"
          icon="bi-puzzle"
          actionText="Create Feature Set"
          onAction={handleRecordScenario}
        />
      )}
      
      {/* Create Feature Modal */}
      <CreateFeatureModal 
        show={showCreateModal}
        onHide={() => setShowCreateModal(false)}
      />
    </Container>
  );
};

export default FeaturesPage;