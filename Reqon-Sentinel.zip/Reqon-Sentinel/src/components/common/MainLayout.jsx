// src/components/common/MainLayout.jsx
import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import CreateProjectModal from '../modals/CreateProjectModal';
import RecordScenarioModal from '../modals/RecordScenarioModal';
import { useProject } from '../../contexts/ProjectContext';
import { useAuth } from '../../contexts/AuthContext';

const MainLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, isRegistered } = useAuth();
  const { currentProject, projects } = useProject();
  
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
  const [showRecordScenarioModal, setShowRecordScenarioModal] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // Check if sidebar is collapsed from localStorage on component mount
  useEffect(() => {
    const storedState = localStorage.getItem('sidebar_collapsed');
    if (storedState !== null) {
      setIsSidebarCollapsed(storedState === 'true');
    }
  }, []);

  // Update when sidebar collapsed state changes externally
  useEffect(() => {
    const handleStorageChange = () => {
      const storedState = localStorage.getItem('sidebar_collapsed');
      if (storedState !== null) {
        setIsSidebarCollapsed(storedState === 'true');
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Set up a MutationObserver to watch for localStorage changes
    const checkForChanges = setInterval(() => {
      const storedState = localStorage.getItem('sidebar_collapsed');
      if (storedState !== null && (storedState === 'true') !== isSidebarCollapsed) {
        setIsSidebarCollapsed(storedState === 'true');
      }
    }, 200);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(checkForChanges);
    };
  }, [isSidebarCollapsed]);

  // Check if user needs to complete registration
  useEffect(() => {
    if (currentUser && !isRegistered) {
      navigate('/register');
    }
  }, [currentUser, isRegistered, navigate]);

  // Check if user needs to create a project
  useEffect(() => {
    if (isRegistered && projects.length === 0) {
      setShowCreateProjectModal(true);
    }
  }, [isRegistered, projects]);

  // Handle record scenario button click
  const handleRecordScenario = () => {
    setShowRecordScenarioModal(true);
  };

  // Handle toggle sidebar on mobile
  const toggleMobileSidebar = () => {
    setIsMobileSidebarOpen(!isMobileSidebarOpen);
  };

  return (
    <div className="reqon-app">
      {/* Sidebar */}
      <Sidebar 
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        currentPath={location.pathname}
      />
      
      {/* Main Content */}
      <div className="main-content-wrapper" 
           style={{ 
             marginLeft: isSidebarCollapsed ? '76px' : '240px', 
             width: 'auto',
             transition: 'margin-left 0.3s ease'
           }}>
        {/* Header */}
        <Header 
          onToggleSidebar={toggleMobileSidebar}
          onRecordScenario={handleRecordScenario}
        />
        
        {/* Main Content Area */}
        <div className="main-content p-3 p-md-4 bg-light" style={{ minHeight: 'calc(100vh - 70px)' }}>
          {currentProject ? (
            <Outlet />
          ) : (
            <div className="d-flex flex-column align-items-center justify-content-center h-100">
              <div className="text-center">
                <div className="mb-3">
                  <i className="bi bi-plus-circle-dotted text-primary" style={{ fontSize: '3rem' }}></i>
                </div>
                <h4>No Projects Yet</h4>
                <p className="text-muted">Create your first project to get started</p>
                <button 
                  className="btn btn-primary"
                  onClick={() => setShowCreateProjectModal(true)}
                >
                  <i className="bi bi-plus-circle me-2"></i>
                  Create Project
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Responsive styles for mobile */}
      <style jsx="true">{`
        @media (max-width: 991.98px) {
          .main-content-wrapper {
            margin-left: 0 !important;
            width: 100% !important;
          }
        }
      `}</style>
      
      {/* Modals */}
      <CreateProjectModal 
        show={showCreateProjectModal}
        onHide={() => setShowCreateProjectModal(false)}
      />
      
      <RecordScenarioModal
        show={showRecordScenarioModal}
        onHide={() => setShowRecordScenarioModal(false)}
      />
    </div>
  );
};

export default MainLayout;
