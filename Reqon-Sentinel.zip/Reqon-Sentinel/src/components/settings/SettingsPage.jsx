import React, { useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Nav, Alert } from 'react-bootstrap';

const SettingsPage = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [saved, setSaved] = useState(false);
  
  // Form states
  const [generalSettings, setGeneralSettings] = useState({
    organizationName: 'Your Company',
    defaultBrowser: 'chrome',
    darkMode: false,
    autoRunTests: true,
    enableSelfHealing: true
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    emailAddress: 'user@example.com',
    slackNotifications: false,
    slackWebhookUrl: '',
    testCompletionAlerts: true,
    failureAlerts: true
  });
  
  const [integrationSettings, setIntegrationSettings] = useState({
    jiraIntegration: false,
    jiraUrl: '',
    jiraApiKey: '',
    githubIntegration: false,
    githubRepo: '',
    githubToken: ''
  });
  
  // Form handlers
  const handleGeneralChange = (e) => {
    const { name, value, type, checked } = e.target;
    setGeneralSettings({
      ...generalSettings,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handleNotificationChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNotificationSettings({
      ...notificationSettings,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  const handleIntegrationChange = (e) => {
    const { name, value, type, checked } = e.target;
    setIntegrationSettings({
      ...integrationSettings,
      [name]: type === 'checkbox' ? checked : value
    });
  };
  
  // Save settings
  const handleSave = () => {
    // Mock saving settings
    console.log('Saving settings...');
    console.log('General:', generalSettings);
    console.log('Notifications:', notificationSettings);
    console.log('Integrations:', integrationSettings);
    
    // Show success message
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };
  
  return (
    <Container fluid className="p-0">
      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-column flex-md-row">
        <div className="mb-3 mb-md-0">
          <h4 className="fw-bold mb-2">Settings</h4>
          <p className="text-muted">Configure your ReQon preferences and integrations</p>
        </div>
        <Button 
          variant="primary"
          onClick={handleSave}
        >
          <i className="bi bi-save me-2"></i>
          Save Changes
        </Button>
      </div>
      
      {/* Success Alert */}
      {saved && (
        <Alert variant="success" className="mb-4" dismissible onClose={() => setSaved(false)}>
          <i className="bi bi-check-circle me-2"></i>
          Settings saved successfully!
        </Alert>
      )}
      
      {/* Settings Content */}
      <Card className="shadow-sm">
        <Card.Header className="bg-white p-0">
          <Nav variant="tabs" activeKey={activeTab} onSelect={setActiveTab}>
            <Nav.Item>
              <Nav.Link eventKey="general">
                <i className="bi bi-gear me-2"></i>
                General
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="notifications">
                <i className="bi bi-bell me-2"></i>
                Notifications
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="integrations">
                <i className="bi bi-puzzle me-2"></i>
                Integrations
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="team">
                <i className="bi bi-people me-2"></i>
                Team
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="scout">
                <i className="bi bi-download me-2"></i>
                Scout
              </Nav.Link>
            </Nav.Item>
          </Nav>
        </Card.Header>
        
        <Card.Body className="p-4">
          {/* General Settings */}
          {activeTab === 'general' && (
            <>
              <h5 className="mb-4">General Settings</h5>
              
              <Form>
                <Row className="mb-4">
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Organization Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="organizationName"
                        value={generalSettings.organizationName}
                        onChange={handleGeneralChange}
                      />
                    </Form.Group>
                    
                    <Form.Group>
                      <Form.Label>Default Browser</Form.Label>
                      <Form.Select
                        name="defaultBrowser"
                        value={generalSettings.defaultBrowser}
                        onChange={handleGeneralChange}
                      >
                        <option value="chrome">Google Chrome</option>
                        <option value="firefox">Mozilla Firefox</option>
                        <option value="edge">Microsoft Edge</option>
                        <option value="safari">Safari</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Check
                        type="switch"
                        id="darkMode"
                        name="darkMode"
                        label="Dark Mode"
                        checked={generalSettings.darkMode}
                        onChange={handleGeneralChange}
                      />
                      <Form.Text className="text-muted">
                        Enable dark mode for the ReQon interface
                      </Form.Text>
                    </Form.Group>
                    
                    <Form.Group className="mb-3">
                      <Form.Check
                        type="switch"
                        id="autoRunTests"
                        name="autoRunTests"
                        label="Auto-run tests after recording"
                        checked={generalSettings.autoRunTests}
                        onChange={handleGeneralChange}
                      />
                      <Form.Text className="text-muted">
                        Automatically run tests after recording with Scout
                      </Form.Text>
                    </Form.Group>
                    
                    <Form.Group>
                      <Form.Check
                        type="switch"
                        id="enableSelfHealing"
                        name="enableSelfHealing"
                        label="Enable self-healing tests"
                        checked={generalSettings.enableSelfHealing}
                        onChange={handleGeneralChange}
                      />
                      <Form.Text className="text-muted">
                        Allow ReQon to automatically fix tests when app UI changes
                      </Form.Text>
                    </Form.Group>
                  </Col>
                </Row>
              </Form>
            </>
          )}
          
          {/* Notification Settings */}
          {activeTab === 'notifications' && (
            <>
              <h5 className="mb-4">Notification Settings</h5>
              
              <Form>
                <Row className="mb-4">
                  <Col md={6}>
                    <Card className="mb-4">
                      <Card.Header className="bg-white">
                        <Form.Check
                          type="switch"
                          id="emailNotifications"
                          name="emailNotifications"
                          label="Email Notifications"
                          checked={notificationSettings.emailNotifications}
                          onChange={handleNotificationChange}
                          className="mb-0 fw-medium"
                        />
                      </Card.Header>
                      <Card.Body>
                        <Form.Group>
                          <Form.Label>Email Address</Form.Label>
                          <Form.Control
                            type="email"
                            name="emailAddress"
                            value={notificationSettings.emailAddress}
                            onChange={handleNotificationChange}
                            disabled={!notificationSettings.emailNotifications}
                          />
                          <Form.Text className="text-muted">
                            We'll send notifications to this address
                          </Form.Text>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                    
                    <Card>
                      <Card.Header className="bg-white">
                        <Form.Check
                          type="switch"
                          id="slackNotifications"
                          name="slackNotifications"
                          label="Slack Notifications"
                          checked={notificationSettings.slackNotifications}
                          onChange={handleNotificationChange}
                          className="mb-0 fw-medium"
                        />
                      </Card.Header>
                      <Card.Body>
                        <Form.Group>
                          <Form.Label>Slack Webhook URL</Form.Label>
                          <Form.Control
                            type="text"
                            name="slackWebhookUrl"
                            value={notificationSettings.slackWebhookUrl}
                            onChange={handleNotificationChange}
                            disabled={!notificationSettings.slackNotifications}
                          />
                          <Form.Text className="text-muted">
                            Enter the webhook URL from Slack
                          </Form.Text>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                  
                  <Col md={6}>
                    <Card>
                      <Card.Header className="bg-white">
                        <h6 className="mb-0">Notification Events</h6>
                      </Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3">
                          <Form.Check
                            type="switch"
                            id="testCompletionAlerts"
                            name="testCompletionAlerts"
                            label="Test Completion Alerts"
                            checked={notificationSettings.testCompletionAlerts}
                            onChange={handleNotificationChange}
                          />
                          <Form.Text className="text-muted">
                            Receive notifications when tests complete
                          </Form.Text>
                        </Form.Group>
                        
                        <Form.Group>
                          <Form.Check
                            type="switch"
                            id="failureAlerts"
                            name="failureAlerts"
                            label="Test Failure Alerts"
                            checked={notificationSettings.failureAlerts}
                            onChange={handleNotificationChange}
                          />
                          <Form.Text className="text-muted">
                            Receive notifications when tests fail
                          </Form.Text>
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
              </Form>
            </>
          )}
          
          {/* Integration Settings */}
          {activeTab === 'integrations' && (
            <>
              <h5 className="mb-4">Integration Settings</h5>
              
              <Form>
                <Row className="mb-4">
                  <Col md={6}>
                    <Card className="mb-4">
                      <Card.Header className="bg-white">
                        <Form.Check
                          type="switch"
                          id="jiraIntegration"
                          name="jiraIntegration"
                          label="Jira Integration"
                          checked={integrationSettings.jiraIntegration}
                          onChange={handleIntegrationChange}
                          className="mb-0 fw-medium"
                        />
                      </Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3">
                          <Form.Label>Jira URL</Form.Label>
                          <Form.Control
                            type="text"
                            name="jiraUrl"
                            value={integrationSettings.jiraUrl}
                            onChange={handleIntegrationChange}
                            disabled={!integrationSettings.jiraIntegration}
                          />
                        </Form.Group>
                        
                        <Form.Group>
                          <Form.Label>Jira API Key</Form.Label>
                          <Form.Control
                            type="password"
                            name="jiraApiKey"
                            value={integrationSettings.jiraApiKey}
                            onChange={handleIntegrationChange}
                            disabled={!integrationSettings.jiraIntegration}
                          />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                  
                  <Col md={6}>
                    <Card>
                      <Card.Header className="bg-white">
                        <Form.Check
                          type="switch"
                          id="githubIntegration"
                          name="githubIntegration"
                          label="GitHub Integration"
                          checked={integrationSettings.githubIntegration}
                          onChange={handleIntegrationChange}
                          className="mb-0 fw-medium"
                        />
                      </Card.Header>
                      <Card.Body>
                        <Form.Group className="mb-3">
                          <Form.Label>GitHub Repository</Form.Label>
                          <Form.Control
                            type="text"
                            name="githubRepo"
                            value={integrationSettings.githubRepo}
                            onChange={handleIntegrationChange}
                            disabled={!integrationSettings.githubIntegration}
                            placeholder="username/repository"
                          />
                        </Form.Group>
                        
                        <Form.Group>
                          <Form.Label>GitHub Token</Form.Label>
                          <Form.Control
                            type="password"
                            name="githubToken"
                            value={integrationSettings.githubToken}
                            onChange={handleIntegrationChange}
                            disabled={!integrationSettings.githubIntegration}
                          />
                        </Form.Group>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
              </Form>
            </>
          )}
          
          {/* Team Settings */}
          {activeTab === 'team' && (
            <>
              <h5 className="mb-4">Team Settings</h5>
              
              <div className="text-center py-4">
                <div className="mb-3">
                  <i className="bi bi-people text-primary display-1"></i>
                </div>
                <h5 className="mb-2">Team Management Coming Soon</h5>
                <p className="text-muted mb-4">
                  In the future, you'll be able to invite team members, manage roles and permissions, and collaborate on testing.
                </p>
                <Button variant="outline-primary" disabled>
                  <i className="bi bi-people me-2"></i>
                  Invite Team Members
                </Button>
              </div>
            </>
          )}
          
          {/* Scout Settings */}
          {activeTab === 'scout' && (
            <>
              <h5 className="mb-4">Scout Desktop App</h5>
              
              <Row className="justify-content-center">
                <Col md={8}>
                  <Card className="mb-4">
                    <Card.Body className="text-center p-4">
                      <div className="mb-3">
                        <i className="bi bi-download text-primary display-1"></i>
                      </div>
                      <h5 className="mb-2">Download ReQon Scout</h5>
                      <p className="text-muted mb-4">
                        ReQon Scout is our desktop app that allows you to easily record test scenarios by interacting with your application.
                      </p>
                      <Row className="g-3 justify-content-center">
                        <Col xs={12} sm={4}>
                          <Button 
                            variant="primary" 
                            className="w-100"
                          >
                            <i className="bi bi-windows me-2"></i>
                            Windows
                          </Button>
                        </Col>
                        <Col xs={12} sm={4}>
                          <Button 
                            variant="primary" 
                            className="w-100"
                          >
                            <i className="bi bi-apple me-2"></i>
                            macOS
                          </Button>
                        </Col>
                        <Col xs={12} sm={4}>
                          <Button 
                            variant="primary" 
                            className="w-100"
                          >
                            <i className="bi bi-ubuntu me-2"></i>
                            Linux
                          </Button>
                        </Col>
                      </Row>
                    </Card.Body>
                  </Card>
                  
                  <Card>
                    <Card.Header className="bg-white">
                      <h6 className="mb-0">Scout Settings</h6>
                    </Card.Header>
                    <Card.Body>
                      <p className="text-muted">
                        These settings will be applied to your Scout desktop app the next time it connects to ReQon.
                      </p>
                      
                      <Form>
                        <Form.Group className="mb-3">
                          <Form.Label>Recording Mode</Form.Label>
                          <Form.Select defaultValue="both">
                            <option value="manual">Manual Recording Only</option>
                            <option value="nlp">NLP Mode Only</option>
                            <option value="both">Both Modes Available</option>
                          </Form.Select>
                          <Form.Text className="text-muted">
                            Choose which recording modes should be available in Scout
                          </Form.Text>
                        </Form.Group>
                        
                        <Form.Group>
                          <Form.Check
                            type="switch"
                            id="captureNetworkCalls"
                            label="Capture Network Calls"
                            defaultChecked={true}
                          />
                          <Form.Text className="text-muted">
                            Record API calls and network requests during test recording
                          </Form.Text>
                        </Form.Group>
                      </Form>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>
            </>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
};

export default SettingsPage;