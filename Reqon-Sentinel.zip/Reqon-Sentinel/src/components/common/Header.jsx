
import React, { useState, useEffect } from 'react';
import { Navbar, Button, Dropdown } from 'react-bootstrap';
import { useAuth } from '../../contexts/AuthContext';
import { useProject } from '../../contexts/ProjectContext';
import { useTheme } from '../../contexts/ThemeContext';
import ProjectSelector from './ProjectSelector';
import CreateProjectModal from '../modals/CreateProjectModal';

const Header = ({ onToggleSidebar, onRecordScenario }) => {
  const { currentUser, logout } = useAuth();
  const { currentProject } = useProject();
  const { darkMode, toggleTheme } = useTheme();
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [daysLeft, setDaysLeft] = useState(14);
  
  // Check if sidebar is collapsed
  useEffect(() => {
    const checkSidebarState = () => {
      const storedState = localStorage.getItem('sidebar_collapsed');
      if (storedState !== null) {
        setIsSidebarCollapsed(storedState === 'true');
      }
    };
    
    // Initial check
    checkSidebarState();
    
    // Set up event listener
    window.addEventListener('storage', checkSidebarState);
    
    return () => {
      window.removeEventListener('storage', checkSidebarState);
    };
  }, []);
  
  const getInitials = (user) => {
    if (user && user.firstName && user.lastName) {
      return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
    }
    return user ? user.email.charAt(0).toUpperCase() : 'U';
  };
  
  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };
  
  return (
    <>
      <Navbar className="header py-2 px-3 bg-white" expand={false}>
        <div className="container-fluid px-0">
          <div className="d-flex align-items-center">
            {/* Mobile Sidebar Toggle */}
            <Button
              variant="link"
              className="d-lg-none p-0 me-3 text-dark border-0"
              onClick={onToggleSidebar}
              aria-label="Toggle sidebar"
            >
              <i className="bi bi-list fs-4"></i>
            </Button>
            
            {/* Project Selector */}
            <ProjectSelector 
              currentProject={currentProject}
              onCreateProject={() => setShowCreateProjectModal(true)}
            />
          </div>
          
          <div className="d-flex align-items-center gap-3">
            {/* Theme Toggle Button */}
            <Button
              variant="light"
              size="sm"
              className="d-flex align-items-center justify-content-center rounded-circle p-0 border-0"
              style={{ width: '36px', height: '36px' }}
              onClick={toggleTheme}
              title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              <i className={`bi ${darkMode ? 'bi-sun' : 'bi-moon'}`}></i>
            </Button>
            
            {/* Record Scenario Button */}
            <Button
              variant="danger"
              size="sm"
              className="d-flex align-items-center rounded-pill py-2 px-3 shadow-sm"
              onClick={onRecordScenario}
            >
              <i className="bi bi-record-circle me-2"></i>
              Record scenario
            </Button>
            
            {/* Days Left Indicator */}
           
            
            
        
          </div>
        </div>
      </Navbar>
      
      {/* Create Project Modal */}
      <CreateProjectModal
        show={showCreateProjectModal}
        onHide={() => setShowCreateProjectModal(false)}
      />
    </>
  );
};

export default Header;
