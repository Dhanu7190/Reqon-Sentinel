// src/components/features/CreateFeatureModal.jsx
import React, { useState } from 'react';
import { Modal, Button, Form, Row, Col, Tab, Nav } from 'react-bootstrap';

const CreateFeatureModal = ({ show, onHide }) => {
  const [activeTab, setActiveTab] = useState('scout');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    steps: '',
    testData: ''
  });
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Handle form submission
  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    console.log('Creating feature set:', formData);
    // Would submit to API in a real implementation
    onHide();
  };
  
  // Reset form when modal is opened/closed
  React.useEffect(() => {
    if (show) {
      setFormData({
        name: '',
        description: '',
        steps: '',
        testData: ''
      });
    }
  }, [show]);
  
  return (
    <Modal 
      show={show} 
      onHide={onHide}
      centered
      size="lg"
    >
      <Modal.Header closeButton>
        <Modal.Title>Create New Feature Set</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Tab.Container activeKey={activeTab} onSelect={setActiveTab}>
          <Nav variant="tabs" className="mb-3">
            <Nav.Item>
              <Nav.Link eventKey="scout">
                <i className="bi bi-puzzle me-2"></i>
                Using Scout App
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="manual">
                <i className="bi bi-pencil me-2"></i>
                Manual Creation
              </Nav.Link>
            </Nav.Item>
          </Nav>
          
          <Tab.Content>
            <Tab.Pane eventKey="scout">
              <p className="text-muted mb-4">
                The easiest way to create a Feature Set is to use Scout to record user journeys or generate them using natural language instructions.
              </p>
              
              <div className="text-center py-4">
                <div className="mb-3">
                  <i className="bi bi-puzzle text-primary display-1"></i>
                </div>
                <h5 className="mb-3">Scout Desktop App</h5>
                <p className="text-muted mb-4">
                  Scout allows you to easily record user journeys and convert them into Feature Sets. It provides both recording mode and NLP mode for intuitive test creation.
                </p>
                <Row className="g-3 justify-content-center">
                  <Col xs={12} sm={4}>
                    <Button 
                      variant="primary" 
                      className="w-100"
                    >
                      <i className="bi bi-download me-2"></i>
                      Windows
                    </Button>
                  </Col>
                  <Col xs={12} sm={4}>
                    <Button 
                      variant="primary" 
                      className="w-100"
                    >
                      <i className="bi bi-download me-2"></i>
                      macOS
                    </Button>
                  </Col>
                  <Col xs={12} sm={4}>
                    <Button 
                      variant="primary" 
                      className="w-100"
                    >
                      <i className="bi bi-download me-2"></i>
                      Linux
                    </Button>
                  </Col>
                </Row>
              </div>
            </Tab.Pane>
            
            <Tab.Pane eventKey="manual">
              <p className="text-muted mb-4">
                Manually create a Feature Set by providing the details below.
              </p>
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Feature Set Name</Form.Label>
                  <Form.Control 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Enter a name for your feature set"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control 
                    as="textarea" 
                    rows={2}
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Enter a description"
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Test Steps</Form.Label>
                  <Form.Control 
                    as="textarea" 
                    rows={6}
                    name="steps"
                    value={formData.steps}
                    onChange={handleInputChange}
                    placeholder="Enter test steps in Gherkin format (Given/When/Then)"
                  />
                  <Form.Text className="text-muted">
                    Example: Given I am on the homepage, When I click the login button, Then I should see the login form
                  </Form.Text>
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Test Data (Optional)</Form.Label>
                  <Form.Control 
                    as="textarea" 
                    rows={4}
                    name="testData"
                    value={formData.testData}
                    onChange={handleInputChange}
                    placeholder="Enter test data in JSON format or as a table"
                  />
                  <Form.Text className="text-muted">
                    {/* Example: {"name": "John Doe", "email": "john@example.com"} */}
                  </Form.Text>
                </Form.Group>
              </Form>
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        {activeTab === 'manual' && (
          <Button variant="primary" onClick={handleSubmit}>
            Create Feature Set
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  );
};

export default CreateFeatureModal;