// src/components/dashboard/RunsChart.jsx
import React from 'react';

const RunsChart = ({ totalRuns, passedRuns }) => {
  // Calculate pass percentage
  const passPercentage = totalRuns > 0 ? (passedRuns / totalRuns) * 100 : 0;
  
  // Calculate circle position
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (passPercentage / 100) * circumference;
  
  return (
    <div className="text-center">
      <div className="position-relative">
        <svg width="280" height="280" viewBox="0 0 280 280" className="mx-auto">
          {/* Background Circle */}
          <circle
            cx="140"
            cy="140"
            r={radius}
            fill="none"
            stroke="#f0f0f0"
            strokeWidth="24"
          />
          
          {/* Progress Circle */}
          <circle
            cx="140"
            cy="140"
            r={radius}
            fill="none"
            stroke="#dc3545" // Use danger color for failed tests
            strokeWidth="24"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            transform="rotate(-90 140 140)"
          />
          
          {/* Text in middle */}
          <g className="chart-text">
            <text
              x="140"
              y="120"
              textAnchor="middle"
              fontSize="16"
              fill="#6c757d"
            >
              All runs
            </text>
            <text
              x="140"
              y="170"
              textAnchor="middle"
              fontSize="72"
              fontWeight="bold"
              fill="#212529"
            >
              {totalRuns}
            </text>
          </g>
        </svg>
        
        {/* Legend */}
        <div className="d-flex justify-content-center mt-3">
          <div className="d-flex align-items-center me-4">
            <div className="bg-success rounded-circle me-2" style={{ width: 12, height: 12 }}></div>
            <span className="text-muted">Passed: {passedRuns}</span>
          </div>
          <div className="d-flex align-items-center">
            <div className="bg-danger rounded-circle me-2" style={{ width: 12, height: 12 }}></div>
            <span className="text-muted">Failed: {totalRuns - passedRuns}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RunsChart;