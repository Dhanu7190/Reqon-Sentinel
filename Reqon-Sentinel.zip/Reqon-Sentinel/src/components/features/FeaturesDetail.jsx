// src/components/features/FeatureDetail.jsx
import React, { useState } from 'react';
import { Modal, Button, Tab, Nav, Card, Badge, Table } from 'react-bootstrap';

const FeatureDetail = ({ feature, show, onHide, onRun }) => {
  const [activeTab, setActiveTab] = useState('steps');
  
  if (!feature) return null;
  
  // Get status badge variant
  const getStatusBadge = (status) => {
    const variant = status === 'Passed' ? 'success' : 'danger';
    const icon = status === 'Passed' ? 'bi-check-circle' : 'bi-x-circle';
    
    return (
      <Badge bg={variant} className="py-2 px-3 d-inline-flex align-items-center">
        <i className={`bi ${icon} me-1`}></i>
        {status}
      </Badge>
    );
  };
  
  return (
    <Modal 
      show={show} 
      onHide={onHide}
      centered
      size="lg"
    >
      <Modal.Header closeButton>
        <Modal.Title className="d-flex align-items-center">
          <i className="bi bi-puzzle me-2 text-primary"></i>
          {feature.name}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="mb-4">
          <div className="d-flex justify-content-between mb-3">
            <div>
              {feature.description && (
                <p className="mb-2">{feature.description}</p>
              )}
              <div>
                <span className="me-3">
                  <i className="bi bi-clock me-1"></i>
                  Last run: {feature.lastRun}
                </span>
                <span>
                  <i className="bi bi-list-check me-1"></i>
                  Scenarios: {feature.scenariosCount}
                </span>
              </div>
            </div>
            <div>
              {getStatusBadge(feature.status)}
            </div>
          </div>
        </div>
        
        <Tab.Container activeKey={activeTab} onSelect={setActiveTab}>
          <Nav variant="tabs" className="mb-3">
            <Nav.Item>
              <Nav.Link eventKey="steps">
                <i className="bi bi-list-check me-2"></i>
                Steps
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="examples">
                <i className="bi bi-table me-2"></i>
                Examples
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="code">
                <i className="bi bi-code-slash me-2"></i>
                Test Code
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="history">
                <i className="bi bi-clock-history me-2"></i>
                History
              </Nav.Link>
            </Nav.Item>
          </Nav>
          
          <Tab.Content>
            <Tab.Pane eventKey="steps">
              <Card>
                <Card.Body>
                  <div className="steps-list">
                    {feature.steps ? (
                      <ul className="list-unstyled mb-0">
                        {feature.steps.map((step, index) => (
                          <li key={index} className="mb-3">
                            <div className="d-flex">
                              <div className="me-3">
                                <Badge 
                                  bg="success" 
                                  pill
                                  className="px-2 py-2 d-inline-flex align-items-center justify-content-center"
                                  style={{ width: '28px', height: '28px' }}
                                >
                                  <i className="bi bi-check"></i>
                                </Badge>
                              </div>
                              <div>
                                <p className="mb-0">{step}</p>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-muted mb-0">No steps defined for this feature.</p>
                    )}
                  </div>
                </Card.Body>
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="examples">
              {feature.examples && feature.examples.length > 0 ? (
                <Card>
                  <Table className="mb-0">
                    <thead className="table-light">
                      <tr>
                        {Object.keys(feature.examples[0]).map((key, index) => (
                          <th key={index}>{key}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {feature.examples.map((example, rowIndex) => (
                        <tr key={rowIndex}>
                          {Object.values(example).map((value, colIndex) => (
                            <td key={colIndex}>{value}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card>
              ) : (
                <p className="text-muted">No examples defined for this feature.</p>
              )}
            </Tab.Pane>
            
            <Tab.Pane eventKey="code">
              <Card>
                <Card.Body>
                  <pre className="bg-light p-3 rounded">
                    {`describe('${feature.name}', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('should complete the feature flow', () => {
    // Generated test code would appear here
    // Based on the recorded steps from Scout
    ${feature.steps ? feature.steps.map(step => `// ${step}`).join('\n    ') : '// No steps defined'}
  });
});`}
                  </pre>
                </Card.Body>
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="history">
              <Card>
                <Table className="mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Date & Time</th>
                      <th>Status</th>
                      <th>Duration</th>
                      <th>User</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{feature.lastRun}</td>
                      <td>{getStatusBadge(feature.status)}</td>
                      <td>2.3s</td>
                      <td>Dhamodhar</td>
                    </tr>
                    <tr>
                      <td>2 days ago</td>
                      <td>{getStatusBadge('Failed')}</td>
                      <td>2.1s</td>
                      <td>Dhamodhar</td>
                    </tr>
                    <tr>
                      <td>3 days ago</td>
                      <td>{getStatusBadge('Passed')}</td>
                      <td>2.4s</td>
                      <td>Dhamodhar</td>
                    </tr>
                  </tbody>
                </Table>
              </Card>
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        <Button 
          variant="primary"
          onClick={() => onRun(feature)}
        >
          <i className="bi bi-play-fill me-2"></i>
          Run Test
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default FeatureDetail;