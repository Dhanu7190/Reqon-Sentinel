// src/components/common/Sidebar.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Offcanvas, Button } from 'react-bootstrap';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';

const Sidebar = ({ isOpen, onClose, currentPath }) => {
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const { darkMode } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  
  // Get stored sidebar state from localStorage if available
  useEffect(() => {
    const storedState = localStorage.getItem('sidebar_collapsed');
    if (storedState !== null) {
      setCollapsed(storedState === 'true');
    }
  }, []);
  
  // Store sidebar state when it changes
  useEffect(() => {
    localStorage.setItem('sidebar_collapsed', collapsed.toString());
  }, [collapsed]);
  
  // Toggle sidebar collapsed state
  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };
  
  // Get user initials for avatar
  const getUserInitials = () => {
    if (currentUser?.firstName && currentUser?.lastName) {
      return `${currentUser.firstName.charAt(0)}${currentUser.lastName.charAt(0)}`;
    }
    return currentUser?.email?.charAt(0).toUpperCase() || 'U';
  };
  
  // Navigation items
  const navItems = [
    {
      label: 'Dashboard',
      icon: 'bi-speedometer',
      path: '/',
      active: currentPath === '/'
    },
    {
      label: 'Features',
      icon: 'bi-puzzle',
      path: '/features',
      active: currentPath === '/features'
    },
    {
      label: 'Reports',
      icon: 'bi-file-text',
      path: '/reports',
      active: currentPath === '/reports'
    },
    {
      label: 'Settings',
      icon: 'bi-gear',
      path: '/settings',
      active: currentPath === '/settings'
    }
  ];
  
  // Handle navigation
  const handleNavigation = (path) => {
    navigate(path);
    onClose(); // Close sidebar on mobile
  };
  
  // Handle logout
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  // Sidebar content (used for both desktop and mobile)
  const SidebarContent = () => (
    <div className="d-flex flex-column h-100">
      {/* Sidebar Header with Logo */}
      <div className={`sidebar-header py-3 ${collapsed ? 'text-center px-2' : 'px-3'}`}>
        <div className="d-flex align-items-center">
          <div className="logo-icon d-flex align-items-center justify-content-center rounded-circle bg-primary me-2"
               style={{ width: '36px', height: '36px' }}>
            <span className="text-white fw-bold">R</span>
          </div>
          {!collapsed && <div className="fw-bold">ReQon</div>}
        </div>
      </div>
      
      {/* Collapse Toggle Button in sticky position */}
      <div className="sidebar-toggle position-absolute" style={{ right: '-13px', top: '30px', zIndex: 1030 }}>
        <Button 
          variant="light" 
          size="sm" 
          className="rounded-circle shadow-sm d-flex align-items-center justify-content-center p-0"
          onClick={toggleSidebar}
          style={{ width: '26px', height: '26px' }}
          title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          <i className={`bi ${collapsed ? 'bi-chevron-right' : 'bi-chevron-left'} fs-6`} style={{ fontSize: '12px' }}></i>
        </Button>
      </div>
      
      {/* Navigation Menu */}
      <div className="sidebar-nav flex-grow-1 overflow-auto pt-3">
        {navItems.map((item, index) => (
          <div 
            key={index}
            className={`sidebar-item ${item.active ? 'sidebar-item-active' : ''}`}
            onClick={() => handleNavigation(item.path)}
          >
            <div className="d-flex align-items-center p-3">
              <i className={`bi ${item.icon} ${collapsed ? '' : 'me-3'}`} style={{ width: collapsed ? 'auto' : '24px' }}></i>
              {!collapsed && <span className="sidebar-item-text">{item.label}</span>}
            </div>
          </div>
        ))}
      </div>
      
      {/* Profile Section */}
      <div className="sidebar-footer mt-auto p-3 border-top">
        <div className={`d-flex ${collapsed ? 'justify-content-center' : 'align-items-center'} mb-3`}>
          <div className="user-avatar d-flex align-items-center justify-content-center rounded-circle text-white bg-primary me-2"
               style={{ width: '36px', height: '36px' }}>
            <span className="fw-bold">{getUserInitials()}</span>
          </div>
          {!collapsed && (
            <div className="text-truncate">
              {currentUser?.email || 'user@example.com'}
            </div>
          )}
        </div>
        
        <Button 
          variant="outline-secondary" 
          className={`d-flex align-items-center ${collapsed ? 'justify-content-center w-100 p-2' : 'w-100'}`} 
          onClick={handleLogout}
        >
          <i className={`bi bi-box-arrow-left ${collapsed ? '' : 'me-3'}`}></i>
          {!collapsed && <span>Logout</span>}
        </Button>
      </div>
    </div>
  );
  
  return (
    <>
      {/* Desktop Sidebar */}
      <div className={`sidebar d-none d-lg-block ${darkMode ? 'sidebar-dark' : ''}`}
           style={{ 
             width: collapsed ? '76px' : '240px', 
             transition: 'width 0.3s ease',
             position: 'fixed',
             top: 0,
             left: 0,
             bottom: 0,
             zIndex: 1030
           }}>
        <SidebarContent />
      </div>
      
      {/* Mobile Sidebar (Offcanvas) */}
      <Offcanvas show={isOpen} onHide={onClose} placement="start" className={`d-lg-none ${darkMode ? 'offcanvas-dark' : ''}`}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>
            <div className="d-flex align-items-center">
              <div className="logo-icon bg-primary rounded-circle d-flex align-items-center justify-content-center me-2"
                   style={{ width: '36px', height: '36px' }}>
                <span className="text-white fw-bold">R</span>
              </div>
              <div className="fw-bold">ReQon</div>
            </div>
          </Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className="p-0">
          <SidebarContent />
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default Sidebar;