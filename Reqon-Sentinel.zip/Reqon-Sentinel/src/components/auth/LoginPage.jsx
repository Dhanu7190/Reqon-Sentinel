// src/components/auth/LoginPage.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Spinner } from 'react-bootstrap';
import { useAuth } from '../../contexts/AuthContext';

const LoginPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const { loginWithSSO, isAuthenticated, isRegistered } = useAuth();
  const navigate = useNavigate();
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      if (isRegistered) {
        navigate('/');
      } else {
        navigate('/register');
      }
    }
  }, [isAuthenticated, isRegistered, navigate]);
  
  // Handle SSO login
  const handleSSOLogin = async (provider) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await loginWithSSO(provider);
      // Redirect will happen in the useEffect above
    } catch (error) {
      console.error('Login failed:', error);
      setError('Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Container className="vh-100 d-flex align-items-center justify-content-center">
      <Row className="justify-content-center w-100">
        <Col xs={12} sm={9} md={7} lg={5} xl={4}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="p-4 p-sm-5">
              <div className="text-center mb-4">
                <div className="logo-icon mx-auto mb-3 bg-primary rounded-circle d-flex align-items-center justify-content-center"
                     style={{ width: '60px', height: '60px' }}>
                  <span className="text-white fw-bold fs-4">R</span>
                </div>
                <h3 className="fw-bold">ReQon</h3>
                <p className="text-muted">AI-Powered Quality Assurance</p>
              </div>
              
              {error && (
                <div className="alert alert-danger">{error}</div>
              )}
              
              <div className="mb-4">
                <h5 className="mb-3 text-center">Sign in to your account</h5>
                
                <div className="d-grid gap-3">
                  <Button
                    variant="outline-secondary"
                    className="d-flex align-items-center justify-content-center py-2"
                    onClick={() => handleSSOLogin('google')}
                    disabled={isLoading}
                  >
                    <img 
                      src="/assets/images/google-icon.svg" 
                      alt="Google" 
                      className="me-2"
                      width="20"
                      height="20"
                    />
                    Sign in with Google
                  </Button>
                  
                  <Button
                    variant="outline-secondary"
                    className="d-flex align-items-center justify-content-center py-2"
                    onClick={() => handleSSOLogin('microsoft')}
                    disabled={isLoading}
                  >
                    <img 
                      src="/assets/images/microsoft-icon.svg" 
                      alt="Microsoft" 
                      className="me-2"
                      width="20"
                      height="20"
                    />
                    Sign in with Microsoft
                  </Button>
                  
                  <Button
                    variant="outline-secondary"
                    className="d-flex align-items-center justify-content-center py-2"
                    onClick={() => handleSSOLogin('github')}
                    disabled={isLoading}
                  >
                    <img 
                      src="/assets/images/github-icon.svg" 
                      alt="GitHub" 
                      className="me-2"
                      width="20"
                      height="20"
                    />
                    Sign in with GitHub
                  </Button>
                </div>
              </div>
              
              {isLoading && (
                <div className="text-center">
                  <Spinner animation="border" variant="primary" />
                  <p className="mt-2 text-muted">Authenticating...</p>
                </div>
              )}
              
              <div className="text-center mt-4 small text-muted">
                By signing in, you agree to our <a href="#terms">Terms of Service</a> and <a href="#privacy">Privacy Policy</a>.
              </div>
            </Card.Body>
          </Card>
          
          <div className="text-center mt-4">
            <p className="small text-muted">
              &copy; {new Date().getFullYear()} ReQon. All rights reserved.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default LoginPage;