// src/components/dashboard/Dashboard.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { mockDashboardStats, mockExecutions } from '../../data/mockData';

const Dashboard = () => {
  const navigate = useNavigate();
  const hasData = mockExecutions.length > 0;
  
  return (
    <div>
      {/* Page Header */}
      <h2 className="mb-4 fw-bold">Hi Dhamodhar! Here is your testing status</h2>
      
      {/* Stats Row */}
      <div className="row g-4 mb-4">
        <div className="col-md-4">
          <div className="stat-card">
            <div className="stat-icon stat-icon-features">
              <i className="bi bi-puzzle fs-4 text-primary"></i>
            </div>
            <div>
              <p className="stat-label">Feature total</p>
              <h2 className="stat-value">{mockDashboardStats.featureTotal}</h2>
            </div>
          </div>
        </div>
        
        <div className="col-md-4">
          <div className="stat-card">
            <div className="stat-icon stat-icon-scenarios">
              <i className="bi bi-list fs-4 text-info"></i>
            </div>
            <div>
              <p className="stat-label">Scenarios total</p>
              <h2 className="stat-value">{mockDashboardStats.scenariosTotal}</h2>
            </div>
          </div>
        </div>
        
        <div className="col-md-4">
          <div className="stat-card">
            <div className="stat-icon stat-icon-runs">
              <i className="bi bi-play-circle fs-4 text-success"></i>
            </div>
            <div>
              <p className="stat-label">Runs last week</p>
              <h2 className="stat-value">{mockDashboardStats.runsLastWeek}</h2>
            </div>
          </div>
        </div>
      </div>
      
      {/* Latest Executions */}
      <div className="card-container mb-4">
        <div className="section-heading">
          <h2>Latest executions</h2>
          <a href="#" className="show-all-link" onClick={() => navigate('/reports')}>
            Show all <i className="bi bi-arrow-right ms-1"></i>
          </a>
        </div>
        
        <div className="table-responsive">
          <table className="execution-table">
            <thead>
              <tr>
                <th>EXECUTION NAME</th>
                <th>EXECUTION DATE</th>
                <th>EXECUTION TYPE</th>
                <th>STATUS</th>
                <th>PASS RATIO</th>
              </tr>
            </thead>
            <tbody>
              {mockExecutions.map((execution, index) => (
                <tr key={index}>
                  <td>{execution.name}</td>
                  <td>{execution.date} at {execution.time}</td>
                  <td>
                    <span className="d-flex align-items-center">
                      <i className="bi bi-laptop me-2"></i>
                      Local execution
                    </span>
                  </td>
                  <td>
                    <span className="badge badge-failed px-3 py-2">Failed</span>
                  </td>
                  <td>0/1 (0%)</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Bottom Row */}
      <div className="row g-4">
        <div className="col-md-8">
          <div className="card-container">
            <h2 className="mb-4">Overall runs</h2>
            <div className="text-center p-5">
              <div className="gauge-chart" style={{ position: 'relative' }}>
                <svg viewBox="0 0 200 200" width="200" height="200">
                  <circle
                    cx="100"
                    cy="100"
                    r="80"
                    fill="none"
                    stroke="#f1f1f1"
                    strokeWidth="20"
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="80"
                    fill="none"
                    stroke="#dc3545"
                    strokeWidth="20"
                    strokeDasharray={2 * Math.PI * 80}
                    strokeDashoffset={2 * Math.PI * 80 * (1 - 3/3)}
                    transform="rotate(-90 100 100)"
                  />
                  <text
                    x="100"
                    y="85"
                    textAnchor="middle"
                    fontSize="12"
                    fill="#6b7280"
                  >
                    All runs
                  </text>
                  <text
                    x="100"
                    y="120"
                    textAnchor="middle"
                    fontSize="40"
                    fontWeight="bold"
                    fill="#333"
                  >
                    3
                  </text>
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        <div className="col-md-4">
          <div className="card-container">
            <h2 className="mb-4">Code Fixes</h2>
            <div className="text-center p-4">
              <div style={{ height: '200px' }} className="d-flex flex-column align-items-center justify-content-center">
                <div className="mb-3">
                  <i className="bi bi-gear fs-1 text-secondary opacity-50"></i>
                </div>
                <h6>No code fixes done by AI</h6>
                <p className="text-muted small mb-0">
                  Automatic code fixes will appear here when AI detects issues
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {hasData ? null : (
        <div className="text-center p-5">
          <div className="mb-3">
            <i className="bi bi-play-circle text-primary" style={{ fontSize: '3rem' }}></i>
          </div>
          <h4>No executions yet</h4>
          <p className="text-muted">Start recording scenarios to see your test executions here</p>
          <button className="btn btn-primary">
            Record Scenario
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
