// src/components/dashboard/StatsCard.jsx
import React from 'react';
import { Card } from 'react-bootstrap';

const StatsCard = ({ title, value, icon, color }) => {
  // Define color classes based on color prop
  const getColorClasses = (colorName) => {
    switch (colorName) {
      case 'primary':
        return { bg: 'bg-primary-light', text: 'text-primary' };
      case 'success':
        return { bg: 'bg-success-light', text: 'text-success' };
      case 'danger':
        return { bg: 'bg-danger-light', text: 'text-danger' };
      case 'warning':
        return { bg: 'bg-warning-light', text: 'text-warning' };
      case 'info':
        return { bg: 'bg-info-light', text: 'text-info' };
      default:
        return { bg: 'bg-light', text: 'text-secondary' };
    }
  };
  
  const colorClasses = getColorClasses(color);
  
  return (
    <Card className="h-100 shadow-sm">
      <Card.Body className="d-flex align-items-center">
        <div className={`rounded-circle p-3 me-3 ${colorClasses.bg}`}>
          <i className={`bi ${icon} ${colorClasses.text} fs-4`}></i>
        </div>
        <div>
          <h6 className="text-muted mb-1">{title}</h6>
          <h3 className="mb-0 fw-bold">{value}</h3>
        </div>
      </Card.Body>
    </Card>
  );
};

export default StatsCard;