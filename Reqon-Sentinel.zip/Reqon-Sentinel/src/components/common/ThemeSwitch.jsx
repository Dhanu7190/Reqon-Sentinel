// src/components/common/ThemeSwitch.jsx
import React, { useState, useEffect } from 'react';
import { Form } from 'react-bootstrap';

const ThemeSwitch = () => {
  const [darkMode, setDarkMode] = useState(false);
  
  // Initialize from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('reqon_theme');
    if (savedTheme === 'dark') {
      setDarkMode(true);
      document.documentElement.classList.add('dark-theme');
    }
  }, []);
  
  // Handle theme switch
  const handleThemeSwitch = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark-theme');
      localStorage.setItem('reqon_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark-theme');
      localStorage.setItem('reqon_theme', 'light');
    }
  };
  
  return (
    <div className="theme-switch d-flex align-items-center justify-content-between">
      <div className="d-flex align-items-center">
        <i className={`bi ${darkMode ? 'bi-moon-stars-fill' : 'bi-sun-fill'} me-2 ${darkMode ? 'text-info' : 'text-warning'}`}></i>
        <span>{darkMode ? 'Dark Mode' : 'Light Mode'}</span>
      </div>
      <Form.Check 
        type="switch"
        id="theme-switch"
        checked={darkMode}
        onChange={handleThemeSwitch}
        className="ms-2"
      />
    </div>
  );
};

export default ThemeSwitch;