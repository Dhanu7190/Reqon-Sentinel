// src/components/modals/RecordScenarioModal.jsx
import React, { useState } from 'react';
import { Modal, Button, Tab, Nav, Card } from 'react-bootstrap';

const RecordScenarioModal = ({ show, onHide }) => {
  const [activeTab, setActiveTab] = useState('windows');
  
  const DownloadButton = ({ platform, icon }) => (
    <Button 
      variant="primary" 
      className="w-100 d-flex align-items-center justify-content-center"
      onClick={() => window.open(`https://download.reqon.ai/${platform}`, '_blank')}
    >
      <i className={`bi ${icon} me-2`}></i>
      Download for {platform}
    </Button>
  );
  
  return (
    <Modal
      show={show}
      onHide={onHide}
      centered
      size="lg"
    >
      <Modal.Header closeButton>
        <Modal.Title>Download ReQon Scout</Modal.Title>
      </Modal.Header>
      
      <Modal.Body>
        <p className="text-muted mb-4">
          ReQon Scout is our desktop app that allows you to easily record test scenarios by interacting with your application. Download it to get started with automated testing.
        </p>
        
        <div className="text-center mb-4">
          <div className="d-inline-block bg-primary bg-opacity-10 rounded-circle p-4 mb-3">
            <i className="bi bi-download text-primary display-5"></i>
          </div>
          <h5>Download ReQon Scout</h5>
          <p className="text-muted">
            Select your operating system below to download the installer
          </p>
        </div>
        
        <Tab.Container activeKey={activeTab} onSelect={setActiveTab}>
          <Nav variant="pills" className="justify-content-center mb-4">
            <Nav.Item>
              <Nav.Link eventKey="windows">
                <i className="bi bi-windows me-2"></i>
                Windows
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="mac">
                <i className="bi bi-apple me-2"></i>
                macOS
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="linux">
                <i className="bi bi-ubuntu me-2"></i>
                Linux
              </Nav.Link>
            </Nav.Item>
          </Nav>
          
          <Tab.Content>
            <Tab.Pane eventKey="windows">
              <Card body className="text-center">
                <h6 className="mb-3">Windows 10 or later</h6>
                <DownloadButton platform="Windows" icon="bi-windows" />
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="mac">
              <Card body className="text-center">
                <h6 className="mb-3">macOS 11.0 or later</h6>
                <DownloadButton platform="macOS" icon="bi-apple" />
              </Card>
            </Tab.Pane>
            
            <Tab.Pane eventKey="linux">
              <Card body className="text-center">
                <h6 className="mb-3">Ubuntu 20.04 or later</h6>
                <DownloadButton platform="Linux" icon="bi-ubuntu" />
              </Card>
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
        
        <div className="mt-4">
          <h6>Why use ReQon Scout?</h6>
          <ul className="text-muted">
            <li>Record user journeys through your application</li>
            <li>Use natural language to automate testing</li>
            <li>Generate comprehensive test scenarios automatically</li>
            <li>Capture DOM elements, network calls, and more</li>
            <li>Self-healing tests that adapt to UI changes</li>
          </ul>
        </div>
      </Modal.Body>
      
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default RecordScenarioModal;