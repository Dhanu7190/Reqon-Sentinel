// src/components/auth/RegisterPage.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Form, Button, Spinner } from 'react-bootstrap';
import { useAuth } from '../../contexts/AuthContext';

const RegisterPage = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  
  const { currentUser, isAuthenticated, isRegistered, register } = useAuth();
  const navigate = useNavigate();
  
  // Redirect if not authenticated or already registered
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    } else if (isRegistered) {
      navigate('/');
    }
  }, [isAuthenticated, isRegistered, navigate]);
  
  // Validate the form
  const validateForm = () => {
    const newErrors = {};
    
    if (!firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }
    
    if (!companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await register(firstName, lastName, companyName);
      navigate('/');
    } catch (error) {
      console.error('Registration failed:', error);
      setErrors({ form: 'Registration failed. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Container className="vh-100 d-flex align-items-center justify-content-center">
      <Row className="justify-content-center w-100">
        <Col xs={12} sm={10} md={8} lg={6} xl={5}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="p-4 p-sm-5">
              <div className="text-center mb-4">
                <div className="logo-icon mx-auto mb-3 bg-primary rounded-circle d-flex align-items-center justify-content-center"
                     style={{ width: '60px', height: '60px' }}>
                  <span className="text-white fw-bold fs-4">R</span>
                </div>
                <h3 className="fw-bold">Welcome to ReQon</h3>
                <p className="text-muted">Complete your profile to get started</p>
              </div>
              
              {errors.form && (
                <div className="alert alert-danger">{errors.form}</div>
              )}
              
              <div className="d-flex align-items-center mb-4">
                <div className="user-avatar d-flex align-items-center justify-content-center rounded-circle text-white bg-primary me-3"
                     style={{ width: '48px', height: '48px' }}>
                  <span className="fw-bold">
                    {currentUser?.email?.charAt(0).toUpperCase() || 'U'}
                  </span>
                </div>
                <div>
                  <p className="mb-0 fw-medium">{currentUser?.email}</p>
                  <small className="text-muted">
                    Signed in with {currentUser?.provider || 'SSO'}
                  </small>
                </div>
              </div>
              
              <Form onSubmit={handleSubmit}>
                <Row className="mb-3">
                  <Col md={6}>
                    <Form.Group className="mb-3 mb-md-0">
                      <Form.Label>First Name</Form.Label>
                      <Form.Control
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        isInvalid={!!errors.firstName}
                        disabled={isSubmitting}
                        autoFocus
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.firstName}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group>
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        isInvalid={!!errors.lastName}
                        disabled={isSubmitting}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.lastName}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-4">
                  <Form.Label>Company Name</Form.Label>
                  <Form.Control
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    isInvalid={!!errors.companyName}
                    disabled={isSubmitting}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.companyName}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <div className="d-grid">
                  <Button 
                    variant="primary" 
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden="true"
                          className="me-2"
                        />
                        Completing...
                      </>
                    ) : (
                      'Complete Registration'
                    )}
                  </Button>
                </div>
              </Form>
              
              <div className="text-center mt-4 small text-muted">
                By registering, you agree to our <a href="#terms">Terms of Service</a> and <a href="#privacy">Privacy Policy</a>.
              </div>
            </Card.Body>
          </Card>
          
          <div className="text-center mt-4">
            <p className="small text-muted">
              &copy; {new Date().getFullYear()} ReQon. All rights reserved.
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default RegisterPage;