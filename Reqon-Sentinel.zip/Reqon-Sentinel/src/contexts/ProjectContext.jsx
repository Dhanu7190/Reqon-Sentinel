// src/contexts/ProjectContext.jsx
import React, { createContext, useState, useContext, useEffect } from 'react';

// Create Project Context
const ProjectContext = createContext();

// Project Provider Component
export const ProjectProvider = ({ children }) => {
  const [projects, setProjects] = useState([]);
  const [currentProject, setCurrentProject] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if projects exist in localStorage
  useEffect(() => {
    const savedProjects = localStorage.getItem('reqon_projects');
    const currentProjectId = localStorage.getItem('reqon_current_project');
    
    const projectsList = savedProjects ? JSON.parse(savedProjects) : [];
    
    if (projectsList.length > 0) {
      setProjects(projectsList);
      
      // Set current project
      if (currentProjectId) {
        const current = projectsList.find(p => p.id === parseInt(currentProjectId));
        setCurrentProject(current || projectsList[0]);
      } else {
        setCurrentProject(projectsList[0]);
      }
    }
    
    setLoading(false);
  }, []);

  // Save projects to localStorage whenever they change
  useEffect(() => {
    if (projects.length > 0) {
      localStorage.setItem('reqon_projects', JSON.stringify(projects));
    }
  }, [projects]);

  // Save current project to localStorage whenever it changes
  useEffect(() => {
    if (currentProject) {
      localStorage.setItem('reqon_current_project', currentProject.id.toString());
    }
  }, [currentProject]);

  // Create new project
  const createProject = (name, url) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const newProject = {
          id: Date.now(),
          name,
          url,
          createdAt: new Date().toISOString(),
          features: [],
          reports: []
        };
        
        const updatedProjects = [...projects, newProject];
        setProjects(updatedProjects);
        setCurrentProject(newProject);
        
        localStorage.setItem('reqon_projects', JSON.stringify(updatedProjects));
        localStorage.setItem('reqon_current_project', newProject.id.toString());
        
        resolve(newProject);
      }, 800);
    });
  };

  // Switch to a different project
  const switchProject = (projectId) => {
    const project = projects.find(p => p.id === projectId);
    if (project) {
      setCurrentProject(project);
      localStorage.setItem('reqon_current_project', project.id.toString());
      return true;
    }
    return false;
  };

  const value = {
    projects,
    currentProject,
    createProject,
    switchProject,
    loading
  };

  return (
    <ProjectContext.Provider value={value}>
      {!loading && children}
    </ProjectContext.Provider>
  );
};

// Custom Project Hook
export const useProject = () => {
  return useContext(ProjectContext);
};

export default ProjectContext;