// src/contexts/AuthContext.jsx
import React, { createContext, useState, useContext, useEffect } from 'react';

// Create Auth Context
const AuthContext = createContext();

// Auth Provider Component
export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [loading, setLoading] = useState(true);

  // Check if user is already logged in (from localStorage)
  useEffect(() => {
    const user = localStorage.getItem('reqon_user');
    const registered = localStorage.getItem('reqon_registered');
    
    if (user) {
      setCurrentUser(JSON.parse(user));
      setIsAuthenticated(true);
    }
    
    if (registered) {
      setIsRegistered(true);
    }
    
    setLoading(false);
  }, []);

  // SSO login function
  const loginWithSSO = (provider) => {
    return new Promise((resolve, reject) => {
      // Mock SSO authentication
      setTimeout(() => {
        const user = {
          id: 1,
          email: `user@example.com`,
          provider: provider,
          picture: null
        };
        
        localStorage.setItem('reqon_user', JSON.stringify(user));
        setCurrentUser(user);
        setIsAuthenticated(true);
        resolve(user);
      }, 1000);
    });
  };

  // Registration function
  const register = (firstName, lastName, companyName) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (currentUser) {
          const updatedUser = {
            ...currentUser,
            firstName,
            lastName,
            companyName
          };
          
          localStorage.setItem('reqon_user', JSON.stringify(updatedUser));
          localStorage.setItem('reqon_registered', 'true');
          setCurrentUser(updatedUser);
          setIsRegistered(true);
          resolve(updatedUser);
        } else {
          reject(new Error('User not authenticated'));
        }
      }, 800);
    });
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('reqon_user');
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  const value = {
    currentUser,
    isAuthenticated,
    isRegistered,
    loginWithSSO,
    register,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

// Custom Auth Hook
export const useAuth = () => {
  return useContext(AuthContext);
};

export default AuthContext;