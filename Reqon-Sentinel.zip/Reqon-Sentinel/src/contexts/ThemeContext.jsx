// src/contexts/ThemeContext.jsx
import React, { createContext, useState, useContext, useEffect } from 'react';

// Create Theme Context
const ThemeContext = createContext();

// Theme Provider Component
export const ThemeProvider = ({ children }) => {
  const [darkMode, setDarkMode] = useState(false);
  
  // Initialize from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('reqon_theme');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    const shouldUseDarkMode = savedTheme === 'dark' || (savedTheme === null && prefersDark);
    
    if (shouldUseDarkMode) {
      setDarkMode(true);
      document.documentElement.classList.add('dark-theme');
    }
  }, []);
  
  // Toggle theme function
  const toggleTheme = () => {
    setDarkMode(prevMode => {
      const newMode = !prevMode;
      
      if (newMode) {
        document.documentElement.classList.add('dark-theme');
        localStorage.setItem('reqon_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark-theme');
        localStorage.setItem('reqon_theme', 'light');
      }
      
      return newMode;
    });
  };
  
  // Set specific theme
  const setTheme = (mode) => {
    const isDark = mode === 'dark';
    setDarkMode(isDark);
    
    if (isDark) {
      document.documentElement.classList.add('dark-theme');
      localStorage.setItem('reqon_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark-theme');
      localStorage.setItem('reqon_theme', 'light');
    }
  };
  
  return (
    <ThemeContext.Provider value={{ darkMode, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom Hook for using the theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export default ThemeContext;