// src/data/mockData.js

// Mock data for executions
export const mockExecutions = [
  {
    id: 1,
    name: "Submit contact form@debug",
    date: "May 21, 2025",
    time: "11:36:55 AM",
    type: "Local execution",
    status: "Failed",
    passRatio: "0/1 (0%)",
    user: "Dhamodhar",
    environment: "default"
  },
  {
    id: 2,
    name: "Submit contact form@debug",
    date: "May 21, 2025",
    time: "11:33:45 AM",
    type: "Local execution",
    status: "Failed",
    passRatio: "0/1 (0%)",
    user: "Dhamodhar",
    environment: "default"
  },
  {
    id: 3,
    name: "Submit Contact Form@debug",
    date: "May 21, 2025",
    time: "11:19:38 AM",
    type: "Local execution",
    status: "Failed",
    passRatio: "0/1 (0%)",
    user: "Dhamodhar",
    environment: "default"
  }
];

// Mock data for features
export const mockFeatures = [
  {
    id: 1,
    name: "Submit Contact Form",
    description: "Form submission test with validation",
    scenariosCount: 3,
    lastRun: "2 hours ago",
    status: "Failed",
    steps: [
      "Given The user navigates to the Contact page through the Home and Artificial Intelligence links",
      "When The user fills the contact form with full name, email address, company name",
      "When The user navigates to the contact page by clicking on Get in Touch link",
      "When The user hovers on Insights"
    ],
    examples: [
      {
        full_name: "Dhamu",
        email_address: "one@gmail.com",
        company_name: "feuji",
        additional_information: "No"
      }
    ]
  },
  {
    id: 2,
    name: "User Registration",
    description: "Testing the registration flow",
    scenariosCount: 2,
    lastRun: "1 day ago",
    status: "Passed"
  },
  {
    id: 3,
    name: "User Authentication",
    description: "Login/logout functionality testing",
    scenariosCount: 4,
    lastRun: "3 days ago",
    status: "Passed"
  }
];

// Mock data for dashboard stats
export const mockDashboardStats = {
  featureTotal: 1,
  scenariosTotal: 0,
  runsLastWeek: 3,
  allRuns: 3,
  passedRuns: 0
};

// Mock data for projects
export const mockProjects = [
  {
    id: 1,
    name: "feuji",
    url: "https://feuji.com",
    createdAt: "2025-05-10T10:30:00.000Z"
  },
  {
    id: 2,
    name: "eCommerce Portal",
    url: "https://shop.example.com",
    createdAt: "2025-05-15T14:20:00.000Z"
  }
];